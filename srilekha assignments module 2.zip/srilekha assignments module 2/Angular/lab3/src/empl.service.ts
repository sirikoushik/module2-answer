import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Iemployee } from './iemployee';

@Injectable({
  providedIn: 'root'
})
export class EmplService {
  
  private employeeUrl='./assets/emp.json';
  constructor(private http:HttpClient) { }
  getemployee():Observable<Iemployee[]>{
    return this.http.get<Iemployee[]>(this.employeeUrl);
  }
 
}
