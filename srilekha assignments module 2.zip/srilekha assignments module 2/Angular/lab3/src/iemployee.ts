export interface Iemployee {
    Id:number;
    Name:String;
    Salary:number;
    Department:String;
}
