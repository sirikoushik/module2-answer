import { Component } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { EmplService } from './empl.service';
import { Iemployee } from './iemployee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project';
  index: number;
  employee:Iemployee[];
  getemployee: any;

  constructor(private emplService: EmplService) { }

  ngOnInit() {
    this.emplService.getemployee().subscribe(
      data=> this.employee = data) ;
  }
  delete(i: number) {
    this.employee.splice(i, 1);
}
add(id,name,salary,department)
{
  this.employee.push({'Id':id,'Name':name, 'Salary':salary, 'Department':department})
}
update(i:number, id, name,salary,department)
{
  this.index=i;
  id.value=this.employee[i].Id;
  name.value=this.employee[i].Name;
  salary.value=this.employee[i].Salary;
  department.value=this.employee[i].Department;
  

  
}
updateclick(eid, ename, esalary, edepartment)
{
  this.employee[this.index].Id=eid.value;
  this.employee[this.index].Name=ename.value;
  this.employee[this.index].Salary=esalary.value;
  this.employee[this.index].Department=edepartment.value;

}
}
