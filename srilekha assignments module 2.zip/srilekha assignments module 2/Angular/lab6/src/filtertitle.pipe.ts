import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filtertitle'
})
export class FiltertitlePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return value.filter((data)=>data.title.indexOf(args)!==-1);
  }

}
