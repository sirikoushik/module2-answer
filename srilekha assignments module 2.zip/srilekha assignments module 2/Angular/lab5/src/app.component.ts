import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title='lab5';
  addProduct(id, name, cost, category)
  {
    console.log(id.toString() +" "+ name.toString()+" " + cost.toString()+" " + category.toString() )
  }
}
