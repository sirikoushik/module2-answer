import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../iemployee';
import { Router } from '@angular/router';
import { EmployeelistService } from '../employeelist.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  employee: IEmployee[]=[];
  id = "";
  name = ""
  email = ""
  phone = ""
  constructor(private employeelistservice:EmployeelistService,private router:Router) { }

  ngOnInit() {
    this.employeelistservice.getEmployee().subscribe((data)=>this.employee=data);
  }
  onSubmit(employeeAdded: IEmployee) {
    this.employeelistservice.addEmployee(employeeAdded);
  }
}
