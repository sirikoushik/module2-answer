export interface IEmployee {
    Id:number;
    Name:string;
    Email:string;
    Phone:number
}
