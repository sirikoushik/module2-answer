import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../iemployee';
import { EmployeelistService } from '../employeelist.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employee:IEmployee[];
  constructor(private employeelistservice:EmployeelistService) { }

  ngOnInit() {
    this.employeelistservice.getEmployee().subscribe((data)=>{
      this.employee=data
    let employee=this.employeelistservice.get();
    for(let emp of employee)
    {
      this.employee.push(emp);
    }
   });
  }
   Delete(i:number){
   
        this.employee.splice(i,1);
      }
}


